// Function to toggle the visibility of the return date field
function toggleReturnDate() {
    const tripType = document.getElementById('tripType').value;
    const returnDateContainer = document.getElementById('returnDateContainer');

    if (tripType === 'round-trip') {
        returnDateContainer.style.display = 'block';
    } else {
        returnDateContainer.style.display = 'none';
    }
}

// Add event listener to the trip type dropdown
document.getElementById('tripType').addEventListener('change', toggleReturnDate);

// Initialize the return date field visibility on page load
document.addEventListener('DOMContentLoaded', function () {
    toggleReturnDate();
});

// Function to handle flight selection (example)
function selectFlight(flightId) {
    alert(`Flight ${flightId} selected! Redirecting to booking page...`);
    // Redirect to booking page (replace with actual URL)
    window.location.href = `/book/${flightId}`;
}